// GENERATED CODE - DO NOT MODIFY BY HAND

// **************************************************************************
// InjectableConfigGenerator
// **************************************************************************

// ignore_for_file: type=lint
// coverage:ignore-file

// ignore_for_file: no_leading_underscores_for_library_prefixes
import 'package:connectivity_plus/connectivity_plus.dart' as _i8;
import 'package:dio/dio.dart' as _i7;
import 'package:flutter_secure_storage/flutter_secure_storage.dart' as _i9;
import 'package:get_it/get_it.dart' as _i1;
import 'package:image_picker/image_picker.dart' as _i10;
import 'package:injectable/injectable.dart' as _i2;
import 'package:package_info_plus/package_info_plus.dart' as _i4;
import 'package:shared_preferences/shared_preferences.dart' as _i3;

import '../../presentation/appointments/presentation/bloc/bloc/appointments_bloc.dart'
    as _i5;
import '../../presentation/auth/blocs/sign_up_bloc/sign_up_bloc.dart' as _i6;
import '../../presentation/auth/data/auth_repository.dart' as _i12;
import '../../presentation/auth/domain/i_auth_repository.dart' as _i11;
import '../modules/modules.dart' as _i15;
import '../services/api_client.dart' as _i13;
import '../services/network_info.dart' as _i14;

// initializes the registration of main-scope dependencies inside of GetIt
Future<_i1.GetIt> $initGetIt(
  _i1.GetIt getIt, {
  String? environment,
  _i2.EnvironmentFilter? environmentFilter,
}) async {
  final gh = _i2.GetItHelper(
    getIt,
    environment,
    environmentFilter,
  );
  final modules = _$Modules();
  await gh.factoryAsync<_i3.SharedPreferences>(
    () => modules.sharedPreferences,
    preResolve: true,
  );
  await gh.factoryAsync<_i4.PackageInfo>(
    () => modules.packageInfo,
    preResolve: true,
  );
  gh.factory<_i5.AppointmentsBloc>(() => _i5.AppointmentsBloc());
  gh.factory<_i6.SignUpBloc>(() => _i6.SignUpBloc());
  gh.lazySingleton<_i7.Dio>(() => modules.dio);
  gh.lazySingleton<_i8.Connectivity>(() => modules.connectivity);
  gh.lazySingleton<_i9.FlutterSecureStorage>(() => modules.storage);
  gh.lazySingleton<_i10.ImagePicker>(() => modules.imagePicker);
  gh.lazySingleton<_i11.IAuthRepository>(() => _i12.AuthRepository());
  gh.lazySingleton<_i13.ApiClient>(() => _i13.ApiClient(
        client: gh<_i7.Dio>(),
        storage: gh<_i9.FlutterSecureStorage>(),
      ));
  gh.lazySingleton<_i14.INetworkInfo>(
      () => _i14.NetworkInfo(connectivity: gh<_i8.Connectivity>()));
  return getIt;
}

class _$Modules extends _i15.Modules {}
