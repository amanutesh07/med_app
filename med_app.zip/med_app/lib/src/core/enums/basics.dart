enum LoadStatus { initial, loading, success, failed }

enum DateTimeType { days, months, years }

enum InputSuffixType { none, obsecure }

enum Role { patient, doctor }
