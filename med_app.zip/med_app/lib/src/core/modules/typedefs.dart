part of 'modules.dart';

typedef FSS = FlutterSecureStorage;
typedef SP = SharedPreferences;
typedef IP = ImagePicker;
