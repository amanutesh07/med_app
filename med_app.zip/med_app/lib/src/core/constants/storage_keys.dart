class StorageKeys {
  static const String token = 'USER_TOKEN';
  static const String userLanguage = 'USER_LANGUAGE';
  static const String userLanguageIndex = 'USER_LANGUAGE_INDEX';
}
