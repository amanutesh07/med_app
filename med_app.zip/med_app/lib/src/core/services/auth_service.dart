import 'dart:convert';

import 'package:http/http.dart' as http;

import '../../mock_data.dart' as userData;

class AuthService {
  static const baseUrl = 'http://127.0.0.1:8000';

  String accessToken = ''; // Initialize with an empty string
  String authToken = ''; // Initialize with an empty string

  Future<bool> isLoggedIn() async {
    return accessToken.isNotEmpty;
  }

  Future<bool> login(String username, String password) async {
    try {
      final createJwt = await http.post(
        Uri.parse('$baseUrl/auth/jwt/create/'),
        body: jsonEncode({'username': username, 'password': password}),
        headers: {'Content-Type': 'application/json'},
      );

      final response = await http.post(
        Uri.parse('$baseUrl/auth/token/login/'),
        body: jsonEncode({'username': username, 'password': password}),
        headers: {'Content-Type': 'application/json'},
      );

      if (response.statusCode == 200 && createJwt.statusCode == 200) {
        final Map<String, dynamic> data = jsonDecode(response.body);

        final Map<String, dynamic> jwtData = jsonDecode(createJwt.body);
        authToken = data['auth_token'];

        accessToken = jwtData['access'];

        userData.username = username;
        userData.accessToken = accessToken;
        userData.authToken = authToken;
        userData.password = password;

        setAccessToken(accessToken);

        setAuthToken(authToken);
        return true;
      } else {
        print('Login failed with status code: ${response.statusCode}');
        return false;
      }
    } catch (e) {
      print('Error during login: $e');
      return false;
    }
  }

  // Function to set the access token
  void setAccessToken(String token) {
    accessToken = token;
  }

  void setAuthToken(String token) {
    authToken = token;
  }

  Future<bool> register(String username, String email, String password) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/auth/users/'),
        body: jsonEncode(
            {'username': username, 'email': email, 'password': password}),
        headers: {'Content-Type': 'application/json'},
      );

      if (response.statusCode == 201) {
        // Registration successful
        userData.username = username;
        userData.email = email;
        userData.password = password;

        return true;
      } else {
        print('Registration failed with status code: ${response.statusCode}');
        return false;
      }
    } catch (e) {
      print('Error during registration: $e');
      return false;
    }
  }
}
