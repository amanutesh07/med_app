import 'package:med_app/src/presentation/appointments/presentation/bloc/bloc/appointments_bloc.dart';
import 'package:med_app/src/presentation/search/models/consultation_mode.dart';
import 'package:med_app/src/presentation/search/models/doctor_model.dart';

String username = '';
String email = '';
String password = '';

String authToken = '';

String accessToken = '';

List<AppointmentModel> appointmentsList = [];

List<DoctorModel> favoriteDoctorsList = [];

List<String> pharmaciesList = [
  'Green Pharmacy',
  'Sanofi Pharmacy',
  'Diamond Pharmacy',
  'St. Joseph Pharmacy',
  'Pfizer Pharmacy',
  'Hypocrates Pharmacy',
  'Pharmacia Pharmacy',
];

List<ConsultationModel> consultationsList = [
  ConsultationModel(
    consultation:
        "Patient presented with symptoms of chest pain and shortness of breath. Conducted physical examination and ordered ECG. Diagnosis: Suspected angina. Recommended further cardiac evaluation and stress test.",
    recommendation:
        "Prescribed nitroglycerin for immediate relief and advised rest. Scheduled follow-up appointment in one week.",
  ),
  ConsultationModel(
    consultation:
        "Patient complained of toothache and gum swelling. Conducted oral examination and found severe decay in molar teeth. Diagnosis: Advanced dental caries with periodontal involvement.",
    recommendation:
        "Performed root canal treatment and prescribed antibiotics and pain relievers. Advised maintaining oral hygiene and regular dental check-ups.",
  ),
  ConsultationModel(
    consultation:
        "Patient presented with symptoms of fever, cough, and body ache. Conducted physical examination and ordered blood tests. Diagnosis: Suspected viral infection.",
    recommendation:
        "Prescribed antipyretics and advised rest. Recommended follow-up appointment in three days.",
  ),
  ConsultationModel(
    consultation:
        "Patient complained of abdominal pain and bloating. Conducted physical examination and ordered ultrasound. Diagnosis: Suspected gastritis.",
    recommendation:
        "Prescribed antacids and advised dietary modifications. Scheduled follow-up appointment in one week.",
  ),
  ConsultationModel(
    consultation:
        "Patient presented with symptoms of headache and dizziness. Conducted physical examination and ordered MRI. Diagnosis: Suspected migraine.",
    recommendation:
        "Prescribed pain relievers and advised stress management. Recommended follow-up appointment in two weeks.",
  ),
  ConsultationModel(
    consultation:
        "Patient complained of joint pain and stiffness. Conducted physical examination and ordered X-ray. Diagnosis: Suspected arthritis.",
    recommendation:
        "Prescribed anti-inflammatory drugs and advised physiotherapy. Scheduled follow-up appointment in one month.",
  ),
  ConsultationModel(
    consultation:
        "Patient presented with symptoms of fatigue and weight gain. Conducted physical examination and ordered thyroid function tests. Diagnosis: Suspected hypothyroidism.",
    recommendation:
        "Prescribed thyroid hormone replacement therapy and advised dietary modifications. Recommended follow-up appointment in six weeks.",
  ),
  ConsultationModel(
    consultation:
        "Patient complained of shortness of breath and wheezing. Conducted physical examination and ordered spirometry. Diagnosis: Suspected asthma.",
    recommendation:
        "Prescribed bronchodilators and advised avoiding triggers. Scheduled follow-up appointment in one month.",
  ),
  ConsultationModel(
    consultation:
        "Patient presented with symptoms of frequent urination and burning sensation. Conducted physical examination and ordered urine tests. Diagnosis: Suspected urinary tract infection.",
    recommendation:
        "Prescribed antibiotics and advised increased fluid intake. Recommended follow-up appointment in one week.",
  ),
  ConsultationModel(
    consultation:
        "Patient complained of vision loss and eye pain. Conducted eye examination and ordered visual field tests. Diagnosis: Suspected glaucoma.",
    recommendation:
        "Prescribed eye drops and advised regular eye check-ups. Scheduled follow-up appointment in one month.",
  ),
  ConsultationModel(
    consultation:
        "Patient presented with symptoms of blood in stool and abdominal cramps. Conducted physical examination and ordered colonoscopy. Diagnosis: Suspected colitis.",
    recommendation:
        "Prescribed anti-inflammatory drugs and advised dietary modifications. Recommended follow-up appointment in two weeks.",
  ),
  ConsultationModel(
    consultation:
        "Patient complained of chest pain and palpitations. Conducted physical examination and ordered ECG. Diagnosis: Suspected arrhythmia.",
    recommendation:
        "Prescribed beta-blockers and advised stress management. Scheduled follow-up appointment in one week.",
  ),
  ConsultationModel(
    consultation:
        "Patient presented with symptoms of memory loss and confusion. Conducted physical examination and ordered MRI. Diagnosis: Suspected dementia.",
    recommendation:
        "Prescribed cholinesterase inhibitors and advised cognitive therapy. Recommended follow-up appointment in one month.",
  ),
  ConsultationModel(
    consultation:
        "Patient complained of skin rash and itching. Conducted physical examination and ordered skin biopsy. Diagnosis: Suspected eczema.",
    recommendation:
        "Prescribed corticosteroids and advised avoiding triggers. Scheduled follow-up appointment in two weeks.",
  ),
  ConsultationModel(
    consultation:
        "Patient presented with symptoms of fatigue and weight loss. Conducted physical examination and ordered thyroid function tests. Diagnosis: Suspected hyperthyroidism.",
    recommendation:
        "Prescribed antithyroid drugs and advised dietary modifications. Recommended follow-up appointment in six weeks.",
  ),
  ConsultationModel(
    consultation:
        "Patient complained of hearing loss and ear pain. Conducted ear examination and ordered audiometry. Diagnosis: Suspected otitis media.",
    recommendation:
        "Prescribed antibiotics and advised ear hygiene. Scheduled follow-up appointment in one week.",
  ),
  ConsultationModel(
    consultation:
        "Patient presented with symptoms of cough and chest pain. Conducted physical examination and ordered chest X-ray. Diagnosis: Suspected pneumonia.",
    recommendation:
        "Prescribed antibiotics and advised rest. Recommended follow-up appointment in one week.",
  ),
  ConsultationModel(
    consultation:
        "Patient complained of abdominal pain and bloating. Conducted physical examination and ordered ultrasound. Diagnosis: Suspected gallstones.",
    recommendation:
        "Prescribed pain relievers and advised dietary modifications. Scheduled follow-up appointment in one week.",
  ),
  ConsultationModel(
    consultation:
        "Patient presented with symptoms of fever and chills. Conducted physical examination and ordered blood tests. Diagnosis: Suspected malaria.",
    recommendation:
        "Prescribed antimalarial drugs and advised rest. Recommended follow-up appointment in three days.",
  ),
  ConsultationModel(
    consultation:
        "Patient complained of joint pain and swelling. Conducted physical examination and ordered blood tests. Diagnosis: Suspected rheumatoid arthritis.",
    recommendation:
        "Prescribed disease-modifying antirheumatic drugs and advised physiotherapy. Scheduled follow-up appointment in one month.",
  ),
  ConsultationModel(
    consultation:
        "Patient presented with symptoms of cough and wheezing. Conducted physical examination and ordered spirometry. Diagnosis: Suspected chronic obstructive pulmonary disease.",
    recommendation:
        "Prescribed bronchodilators and advised avoiding triggers. Recommended follow-up appointment in one month.",
  ),
];

List<DoctorModel> doctorsList = [
  DoctorModel(
    name: 'Dr. John Doe',
    speciality: 'Cardiologist',
    imageUrl: 'https://example.com/doctor1.jpg',
    rating: 5,
    ratingCount: 500,
    experience: '10 years',
    patientCount: '500',
  ),
  DoctorModel(
    name: 'Dr. House',
    speciality: 'Dentist',
    imageUrl: 'https://example.com/doctor2.jpg',
    rating: 4.0,
    experience: '8 years',
    ratingCount: 300,
    patientCount: '300',
  ),
  DoctorModel(
    name: 'Dr. Woods',
    speciality: 'Pediatrician',
    imageUrl: 'https://example.com/doctor3.jpg',
    rating: 4.5,
    experience: '12 years',
    ratingCount: 700,
    patientCount: '700',
  ),
  // Add more entries here...
  DoctorModel(
    name: 'Dr. Patel',
    speciality: 'Oncologist',
    imageUrl: 'https://example.com/doctor4.jpg',
    rating: 3.5,
    experience: '15 years',
    ratingCount: 1000,
    patientCount: '1000',
  ),
  DoctorModel(
    name: 'Dr. Nguyen',
    speciality: 'Psychiatrist',
    imageUrl: 'https://example.com/doctor5.jpg',
    rating: 4.0,
    experience: '9 years',
    ratingCount: 400,
    patientCount: '400',
  ),
  DoctorModel(
    name: 'Dr. Garcia',
    speciality: 'Endocrinologist',
    imageUrl: 'https://example.com/doctor6.jpg',
    rating: 2.5,
    experience: '7 years',
    ratingCount: 250,
    patientCount: '250',
  ),
  DoctorModel(
    name: 'Dr. Kim',
    speciality: 'Orthopedic Surgeon',
    imageUrl: 'https://example.com/doctor7.jpg',
    rating: 5.0,
    experience: '11 years',
    ratingCount: 600,
    patientCount: '600',
  ),
  DoctorModel(
    name: 'Dr. Chen',
    speciality: 'Ophthalmologist',
    imageUrl: 'https://example.com/doctor8.jpg',
    rating: 4.0,
    experience: '6 years',
    ratingCount: 200,
    patientCount: '200',
  ),
  DoctorModel(
    name: 'Dr. Khan',
    speciality: 'Urologist',
    imageUrl: 'https://example.com/doctor9.jpg',
    rating: 4.5,
    experience: '10 years',
    ratingCount: 450,
    patientCount: '450',
  ),
  DoctorModel(
    name: 'Dr. Lopez',
    speciality: 'Pulmonologist',
    imageUrl: 'https://example.com/doctor10.jpg',
    rating: 4.5,
    experience: '9 years',
    ratingCount: 350,
    patientCount: '350',
  ),
  DoctorModel(
    name: 'Dr. Yamamoto',
    speciality: 'Radiologist',
    imageUrl: 'https://example.com/doctor11.jpg',
    rating: 4.0,
    experience: '13 years',
    ratingCount: 800,
    patientCount: '800',
  ),
];
