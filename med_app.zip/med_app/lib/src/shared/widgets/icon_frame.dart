import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:med_app/gen/assets.gen.dart';
import 'package:med_app/src/core/extensions/context_extension.dart';
import 'package:med_app/src/shared/colors/app_colors.dart';

class IconFrame extends StatelessWidget {
  const IconFrame({
    super.key,
    required this.icon,
    this.padding = 16,
    this.title,
  });

  final SvgGenImage icon;
  final double padding;
  final String? title;

  @override
  Widget build(BuildContext context) {
    final iconContainer = Container(
      alignment: Alignment.center,
      padding: EdgeInsets.all(padding),
      decoration: BoxDecoration(
        color: AppColors.white,
        borderRadius: BorderRadius.circular(12),
      ),
      child: icon.svg(alignment: Alignment.center),
    );
    if (title == null) return iconContainer;
    return Column(
      children: [
        iconContainer,
        const Gap(6),
        Text(
          title!,
          style: context.textTheme.labelSmall,
        ),
      ],
    );
  }
}
