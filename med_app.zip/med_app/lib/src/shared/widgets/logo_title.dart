import 'package:flutter/material.dart';
import 'package:med_app/src/core/extensions/context_extension.dart';
import 'package:med_app/src/shared/colors/app_colors.dart';

class LogoTitle extends StatelessWidget {
  const LogoTitle({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Text(
      'MedApp',
      style: context.textTheme.headlineLarge?.copyWith(
        fontWeight: FontWeight.bold,
        color: AppColors.primary,
      ),
    );
  }
}
