// GENERATED CODE - DO NOT MODIFY BY HAND

// **************************************************************************
// AutoRouterGenerator
// **************************************************************************

// ignore_for_file: type=lint
// coverage:ignore-file

// ignore_for_file: no_leading_underscores_for_library_prefixes
import 'package:auto_route/auto_route.dart' as _i17;
import 'package:flutter/material.dart' as _i18;
import 'package:med_app/src/presentation/appointments/presentation/bloc/bloc/appointments_bloc.dart'
    as _i20;
import 'package:med_app/src/presentation/appointments/presentation/screens/appointments_screen.dart'
    as _i1;
import 'package:med_app/src/presentation/appointments/presentation/screens/consultation_screen.dart'
    as _i3;
import 'package:med_app/src/presentation/appointments/presentation/screens/consultations_screen.dart'
    as _i4;
import 'package:med_app/src/presentation/appointments/presentation/screens/payment_screen.dart'
    as _i9;
import 'package:med_app/src/presentation/auth/screens/sign_in_screen.dart'
    as _i13;
import 'package:med_app/src/presentation/auth/screens/sign_up_screen.dart'
    as _i14;
import 'package:med_app/src/presentation/auth/screens/welcome_screen.dart'
    as _i16;
import 'package:med_app/src/presentation/base/splash_screen.dart' as _i15;
import 'package:med_app/src/presentation/calendar/screens/calendar_screen.dart'
    as _i2;
import 'package:med_app/src/presentation/doctor/screens/doctor_screen.dart'
    as _i5;
import 'package:med_app/src/presentation/doctor/screens/favorite_doctors_screen.dart'
    as _i6;
import 'package:med_app/src/presentation/doctor/screens/pharmacies_screen.dart'
    as _i10;
import 'package:med_app/src/presentation/home/screens/home_screen.dart' as _i7;
import 'package:med_app/src/presentation/profile/screens/profile_screen.dart'
    as _i11;
import 'package:med_app/src/presentation/search/models/consultation_mode.dart'
    as _i19;
import 'package:med_app/src/presentation/search/models/doctor_model.dart'
    as _i21;
import 'package:med_app/src/presentation/search/screens/search_screen.dart'
    as _i12;
import 'package:med_app/src/router/nav_router.dart' as _i8;

abstract class $AppRouter extends _i17.RootStackRouter {
  $AppRouter({super.navigatorKey});

  @override
  final Map<String, _i17.PageFactory> pagesMap = {
    AppointmentsRoute.name: (routeData) {
      return _i17.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const _i1.AppointmentsScreen(),
      );
    },
    CalendarRoute.name: (routeData) {
      return _i17.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const _i2.CalendarScreen(),
      );
    },
    ConsultationRoute.name: (routeData) {
      final args = routeData.argsAs<ConsultationRouteArgs>();
      return _i17.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: _i3.ConsultationScreen(
          key: args.key,
          consultation: args.consultation,
          appointment: args.appointment,
        ),
      );
    },
    ConsultationsRoute.name: (routeData) {
      return _i17.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const _i4.ConsultationsScreen(),
      );
    },
    DoctorRoute.name: (routeData) {
      final args = routeData.argsAs<DoctorRouteArgs>();
      return _i17.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: _i5.DoctorScreen(
          key: args.key,
          doctor: args.doctor,
        ),
      );
    },
    FavoriteDoctorsRoute.name: (routeData) {
      return _i17.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const _i6.FavoriteDoctorsScreen(),
      );
    },
    HomeRoute.name: (routeData) {
      return _i17.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const _i7.HomeScreen(),
      );
    },
    NavRouter.name: (routeData) {
      return _i17.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const _i8.NavRouter(),
      );
    },
    PaymentRoute.name: (routeData) {
      final args = routeData.argsAs<PaymentRouteArgs>();
      return _i17.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: _i9.PaymentScreen(
          key: args.key,
          appointment: args.appointment,
        ),
      );
    },
    PharmaciesRoute.name: (routeData) {
      return _i17.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const _i10.PharmaciesScreen(),
      );
    },
    ProfileRoute.name: (routeData) {
      return _i17.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const _i11.ProfileScreen(),
      );
    },
    SearchRoute.name: (routeData) {
      return _i17.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const _i12.SearchScreen(),
      );
    },
    SignInRoute.name: (routeData) {
      return _i17.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const _i13.SignInScreen(),
      );
    },
    SignUpRoute.name: (routeData) {
      return _i17.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const _i14.SignUpScreen(),
      );
    },
    SplashRoute.name: (routeData) {
      return _i17.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const _i15.SplashScreen(),
      );
    },
    WelcomeRoute.name: (routeData) {
      return _i17.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const _i16.WelcomeScreen(),
      );
    },
  };
}

/// generated route for
/// [_i1.AppointmentsScreen]
class AppointmentsRoute extends _i17.PageRouteInfo<void> {
  const AppointmentsRoute({List<_i17.PageRouteInfo>? children})
      : super(
          AppointmentsRoute.name,
          initialChildren: children,
        );

  static const String name = 'AppointmentsRoute';

  static const _i17.PageInfo<void> page = _i17.PageInfo<void>(name);
}

/// generated route for
/// [_i2.CalendarScreen]
class CalendarRoute extends _i17.PageRouteInfo<void> {
  const CalendarRoute({List<_i17.PageRouteInfo>? children})
      : super(
          CalendarRoute.name,
          initialChildren: children,
        );

  static const String name = 'CalendarRoute';

  static const _i17.PageInfo<void> page = _i17.PageInfo<void>(name);
}

/// generated route for
/// [_i3.ConsultationScreen]
class ConsultationRoute extends _i17.PageRouteInfo<ConsultationRouteArgs> {
  ConsultationRoute({
    _i18.Key? key,
    required _i19.ConsultationModel consultation,
    required _i20.AppointmentModel appointment,
    List<_i17.PageRouteInfo>? children,
  }) : super(
          ConsultationRoute.name,
          args: ConsultationRouteArgs(
            key: key,
            consultation: consultation,
            appointment: appointment,
          ),
          initialChildren: children,
        );

  static const String name = 'ConsultationRoute';

  static const _i17.PageInfo<ConsultationRouteArgs> page =
      _i17.PageInfo<ConsultationRouteArgs>(name);
}

class ConsultationRouteArgs {
  const ConsultationRouteArgs({
    this.key,
    required this.consultation,
    required this.appointment,
  });

  final _i18.Key? key;

  final _i19.ConsultationModel consultation;

  final _i20.AppointmentModel appointment;

  @override
  String toString() {
    return 'ConsultationRouteArgs{key: $key, consultation: $consultation, appointment: $appointment}';
  }
}

/// generated route for
/// [_i4.ConsultationsScreen]
class ConsultationsRoute extends _i17.PageRouteInfo<void> {
  const ConsultationsRoute({List<_i17.PageRouteInfo>? children})
      : super(
          ConsultationsRoute.name,
          initialChildren: children,
        );

  static const String name = 'ConsultationsRoute';

  static const _i17.PageInfo<void> page = _i17.PageInfo<void>(name);
}

/// generated route for
/// [_i5.DoctorScreen]
class DoctorRoute extends _i17.PageRouteInfo<DoctorRouteArgs> {
  DoctorRoute({
    _i18.Key? key,
    required _i21.DoctorModel doctor,
    List<_i17.PageRouteInfo>? children,
  }) : super(
          DoctorRoute.name,
          args: DoctorRouteArgs(
            key: key,
            doctor: doctor,
          ),
          initialChildren: children,
        );

  static const String name = 'DoctorRoute';

  static const _i17.PageInfo<DoctorRouteArgs> page =
      _i17.PageInfo<DoctorRouteArgs>(name);
}

class DoctorRouteArgs {
  const DoctorRouteArgs({
    this.key,
    required this.doctor,
  });

  final _i18.Key? key;

  final _i21.DoctorModel doctor;

  @override
  String toString() {
    return 'DoctorRouteArgs{key: $key, doctor: $doctor}';
  }
}

/// generated route for
/// [_i6.FavoriteDoctorsScreen]
class FavoriteDoctorsRoute extends _i17.PageRouteInfo<void> {
  const FavoriteDoctorsRoute({List<_i17.PageRouteInfo>? children})
      : super(
          FavoriteDoctorsRoute.name,
          initialChildren: children,
        );

  static const String name = 'FavoriteDoctorsRoute';

  static const _i17.PageInfo<void> page = _i17.PageInfo<void>(name);
}

/// generated route for
/// [_i7.HomeScreen]
class HomeRoute extends _i17.PageRouteInfo<void> {
  const HomeRoute({List<_i17.PageRouteInfo>? children})
      : super(
          HomeRoute.name,
          initialChildren: children,
        );

  static const String name = 'HomeRoute';

  static const _i17.PageInfo<void> page = _i17.PageInfo<void>(name);
}

/// generated route for
/// [_i8.NavRouter]
class NavRouter extends _i17.PageRouteInfo<void> {
  const NavRouter({List<_i17.PageRouteInfo>? children})
      : super(
          NavRouter.name,
          initialChildren: children,
        );

  static const String name = 'NavRouter';

  static const _i17.PageInfo<void> page = _i17.PageInfo<void>(name);
}

/// generated route for
/// [_i9.PaymentScreen]
class PaymentRoute extends _i17.PageRouteInfo<PaymentRouteArgs> {
  PaymentRoute({
    _i18.Key? key,
    required _i20.AppointmentModel appointment,
    List<_i17.PageRouteInfo>? children,
  }) : super(
          PaymentRoute.name,
          args: PaymentRouteArgs(
            key: key,
            appointment: appointment,
          ),
          initialChildren: children,
        );

  static const String name = 'PaymentRoute';

  static const _i17.PageInfo<PaymentRouteArgs> page =
      _i17.PageInfo<PaymentRouteArgs>(name);
}

class PaymentRouteArgs {
  const PaymentRouteArgs({
    this.key,
    required this.appointment,
  });

  final _i18.Key? key;

  final _i20.AppointmentModel appointment;

  @override
  String toString() {
    return 'PaymentRouteArgs{key: $key, appointment: $appointment}';
  }
}

/// generated route for
/// [_i10.PharmaciesScreen]
class PharmaciesRoute extends _i17.PageRouteInfo<void> {
  const PharmaciesRoute({List<_i17.PageRouteInfo>? children})
      : super(
          PharmaciesRoute.name,
          initialChildren: children,
        );

  static const String name = 'PharmaciesRoute';

  static const _i17.PageInfo<void> page = _i17.PageInfo<void>(name);
}

/// generated route for
/// [_i11.ProfileScreen]
class ProfileRoute extends _i17.PageRouteInfo<void> {
  const ProfileRoute({List<_i17.PageRouteInfo>? children})
      : super(
          ProfileRoute.name,
          initialChildren: children,
        );

  static const String name = 'ProfileRoute';

  static const _i17.PageInfo<void> page = _i17.PageInfo<void>(name);
}

/// generated route for
/// [_i12.SearchScreen]
class SearchRoute extends _i17.PageRouteInfo<void> {
  const SearchRoute({List<_i17.PageRouteInfo>? children})
      : super(
          SearchRoute.name,
          initialChildren: children,
        );

  static const String name = 'SearchRoute';

  static const _i17.PageInfo<void> page = _i17.PageInfo<void>(name);
}

/// generated route for
/// [_i13.SignInScreen]
class SignInRoute extends _i17.PageRouteInfo<void> {
  const SignInRoute({List<_i17.PageRouteInfo>? children})
      : super(
          SignInRoute.name,
          initialChildren: children,
        );

  static const String name = 'SignInRoute';

  static const _i17.PageInfo<void> page = _i17.PageInfo<void>(name);
}

/// generated route for
/// [_i14.SignUpScreen]
class SignUpRoute extends _i17.PageRouteInfo<void> {
  const SignUpRoute({List<_i17.PageRouteInfo>? children})
      : super(
          SignUpRoute.name,
          initialChildren: children,
        );

  static const String name = 'SignUpRoute';

  static const _i17.PageInfo<void> page = _i17.PageInfo<void>(name);
}

/// generated route for
/// [_i15.SplashScreen]
class SplashRoute extends _i17.PageRouteInfo<void> {
  const SplashRoute({List<_i17.PageRouteInfo>? children})
      : super(
          SplashRoute.name,
          initialChildren: children,
        );

  static const String name = 'SplashRoute';

  static const _i17.PageInfo<void> page = _i17.PageInfo<void>(name);
}

/// generated route for
/// [_i16.WelcomeScreen]
class WelcomeRoute extends _i17.PageRouteInfo<void> {
  const WelcomeRoute({List<_i17.PageRouteInfo>? children})
      : super(
          WelcomeRoute.name,
          initialChildren: children,
        );

  static const String name = 'WelcomeRoute';

  static const _i17.PageInfo<void> page = _i17.PageInfo<void>(name);
}
