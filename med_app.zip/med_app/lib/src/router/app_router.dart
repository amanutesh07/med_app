import 'package:auto_route/auto_route.dart';

import 'app_router.gr.dart';

@AutoRouterConfig()
class AppRouter extends $AppRouter {
  @override
  RouteType get defaultRouteType => const RouteType.material();

  @override
  List<AutoRoute> get routes => [
        AutoRoute(page: SplashRoute.page),
        AutoRoute(page: WelcomeRoute.page, initial: true),
        AutoRoute(page: SignInRoute.page),
        AutoRoute(page: SignUpRoute.page),
        AutoRoute(page: DoctorRoute.page),
        AutoRoute(page: AppointmentsRoute.page),
        AutoRoute(page: CalendarRoute.page),
        AutoRoute(page: PharmaciesRoute.page),
        AutoRoute(page: FavoriteDoctorsRoute.page),
        AutoRoute(page: ConsultationRoute.page),
        AutoRoute(page: ConsultationsRoute.page),
        AutoRoute(page: PaymentRoute.page),
        AutoRoute(
          page: NavRouter.page,
          children: [
            AutoRoute(page: SearchRoute.page, maintainState: false),
            AutoRoute(page: AppointmentsRoute.page, maintainState: false),
            AutoRoute(
                page: HomeRoute.page, initial: true, maintainState: false),
            AutoRoute(page: ProfileRoute.page, maintainState: false),
          ],
        ),
      ];
}
