import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:gap/gap.dart';
import 'package:med_app/src/core/extensions/context_extension.dart';
import 'package:med_app/src/shared/colors/app_colors.dart';
import 'package:responsive_sizer/responsive_sizer.dart';

class ReportTile extends StatelessWidget {
  const ReportTile({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 70.w,
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: AppColors.black.withOpacity(0.12),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(
                FontAwesomeIcons.userDoctor,
                size: 16,
              ),
              Gap(2.w),
              Text(
                'Doctor name',
                style: context.textTheme.titleSmall,
              ),
            ],
          ),
          Gap(1.h),
          Row(
            children: [
              const Icon(
                FontAwesomeIcons.clock,
                size: 16,
              ),
              Gap(2.w),
              Text(
                '02.04.2024',
                style: context.textTheme.bodySmall,
              ),
            ],
          ),
          Gap(2.h),
          Text.rich(
            TextSpan(
              text: 'Диагноз: ',
              style: context.textTheme.bodyMedium?.copyWith(
                fontWeight: FontWeight.w800,
              ),
              children: [
                TextSpan(
                  text: 'рак',
                  style: context.textTheme.bodyMedium?.copyWith(
                    fontWeight: FontWeight.w400,
                  ),
                ),
              ],
            ),
          ),
          Gap(1.h),
          Text.rich(
            TextSpan(
              text: 'Описание: ',
              style: context.textTheme.bodyMedium?.copyWith(
                fontWeight: FontWeight.w800,
              ),
              children: [
                TextSpan(
                  text:
                      'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.',
                  style: context.textTheme.bodyMedium?.copyWith(
                    fontWeight: FontWeight.w400,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ],
            ),
          ),
          Gap(1.h),
          Text.rich(
            TextSpan(
              text: 'Заключение: ',
              style: context.textTheme.bodyMedium?.copyWith(
                fontWeight: FontWeight.w800,
              ),
              children: [
                TextSpan(
                  text:
                      'из за этого что, быр нарселер жугып кетты и соган байланысты быр нарсе нарсе',
                  style: context.textTheme.bodyMedium?.copyWith(
                    fontWeight: FontWeight.w400,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
