import 'package:auto_route/auto_route.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:gap/gap.dart';
import 'package:med_app/gen/assets.gen.dart';
import 'package:med_app/src/core/extensions/context_extension.dart';
import 'package:med_app/src/mock_data.dart';
import 'package:med_app/src/shared/app_bar/my_app_bar.dart';
import 'package:med_app/src/shared/colors/app_colors.dart';
import 'package:responsive_sizer/responsive_sizer.dart';

import '../../../router/app_router.gr.dart';

@RoutePage()
class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const MyAppBar(
        title: Text('Profile'),
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Padding(
              padding: const EdgeInsets.all(20.0),
              child: Container(
                height: 10.h,
                decoration: BoxDecoration(
                  color: AppColors.grey,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(15.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Container(
                        height: 50,
                        width: 50,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(width: 1, color: AppColors.button),
                        ),
                        clipBehavior: Clip.hardEdge,
                        child: const Icon(
                          FontAwesomeIcons.user,
                          color: AppColors.black,
                          size: 26,
                        ),
                      ),
                      const Gap(10),
                      Text(
                        username,
                        style: context.textTheme.labelLarge,
                      ),
                      const Spacer(),
                      InkWell(
                        onTap: () {
                          context.router.replace(const SignInRoute());
                        },
                        child: const Icon(
                          Icons.logout,
                          color: Colors.red,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),

            Padding(
              padding: const EdgeInsets.all(20.0),
              child: Container(
                decoration: BoxDecoration(
                  color: AppColors.grey,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(5.0),
                      child: Text(
                        'Personal Information',
                        style: context.textTheme.titleLarge?.copyWith(
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                    const Gap(2),
                    Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 15, vertical: 5),
                      child: Container(
                        height: 40,
                        decoration: BoxDecoration(
                          color: AppColors.background,
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 10,
                            vertical: 5,
                          ),
                          child: Row(
                            children: [
                              Assets.icons.user.svg(
                                color: AppColors.button,
                                height: 20,
                                width: 20,
                              ),
                              const Gap(10),
                              Text(
                                'Personal Data',
                                style: context.textTheme.labelLarge,
                              ),
                              const Spacer(),
                              Text('edit', style: context.textTheme.labelLarge)
                            ],
                          ),
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 15, vertical: 5),
                      child: Container(
                        height: 40,
                        decoration: BoxDecoration(
                          color: AppColors.background,
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 10,
                            vertical: 5,
                          ),
                          child: Row(
                            children: [
                              const Icon(
                                Icons.email,
                                color: AppColors.button,
                              ),
                              const Gap(10),
                              Text(
                                'Email Address',
                                style: context.textTheme.labelLarge,
                              ),
                              const Spacer(),
                              Text('edit', style: context.textTheme.labelLarge)
                            ],
                          ),
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 15, vertical: 5),
                      child: Container(
                        height: 40,
                        decoration: BoxDecoration(
                          color: AppColors.background,
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 10,
                            vertical: 5,
                          ),
                          child: Row(
                            children: [
                              const Icon(
                                Icons.lock,
                                color: AppColors.button,
                              ),
                              const Gap(10),
                              Text(
                                'Password',
                                style: context.textTheme.labelLarge,
                              ),
                              const Spacer(),
                              Text('edit', style: context.textTheme.labelLarge)
                            ],
                          ),
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 15, vertical: 5),
                      child: Container(
                        height: 40,
                        decoration: BoxDecoration(
                          color: AppColors.background,
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 10,
                            vertical: 5,
                          ),
                          child: Row(
                            children: [
                              const Icon(
                                Icons.book_rounded,
                                color: AppColors.button,
                              ),
                              const Gap(10),
                              Text(
                                'Reports',
                                style: context.textTheme.labelLarge,
                              ),
                              const Spacer(),
                              Text('edit', style: context.textTheme.labelLarge)
                            ],
                          ),
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 15, vertical: 5),
                      child: Container(
                        height: 40,
                        decoration: BoxDecoration(
                          color: AppColors.background,
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 10,
                            vertical: 5,
                          ),
                          child: Row(
                            children: [
                              const Icon(
                                Icons.bookmark,
                                color: AppColors.button,
                              ),
                              const Gap(10),
                              Text(
                                'Saved',
                                style: context.textTheme.labelLarge,
                              ),
                              const Spacer(),
                              Text('edit', style: context.textTheme.labelLarge)
                            ],
                          ),
                        ),
                      ),
                    ),
                    const Gap(15)
                  ],
                ),
              ),
            ),

            // Text(
            //   'Reports',
            //   style: context.textTheme.titleLarge?.copyWith(
            //     fontWeight: FontWeight.w600,
            //   ),
            // ),
            // Gap(2.h),
            // SizedBox(
            //   height: 40.h,
            //   child: ListView.separated(
            //     scrollDirection: Axis.horizontal,
            //     itemBuilder: (context, index) => const ReportTile(),
            //     separatorBuilder: (context, index) => Gap(3.w),
            //     itemCount: 4,
            //   ),
            // ),
          ],
        ),
      ),
    );
  }
}
