import 'package:auto_route/auto_route.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:gap/gap.dart';
import 'package:med_app/src/core/extensions/context_extension.dart';
import 'package:med_app/src/mock_data.dart';
import 'package:med_app/src/presentation/appointments/presentation/bloc/bloc/appointments_bloc.dart';
import 'package:med_app/src/presentation/doctor/widgets/appointment_option_tile.dart';
import 'package:med_app/src/presentation/doctor/widgets/proffesional_doctor_badge.dart';
import 'package:med_app/src/presentation/doctor/widgets/rating_widget.dart';
import 'package:med_app/src/presentation/search/models/doctor_model.dart';
import 'package:med_app/src/router/app_router.gr.dart';
import 'package:med_app/src/shared/colors/app_colors.dart';
import 'package:responsive_sizer/responsive_sizer.dart';

@RoutePage()
class DoctorScreen extends StatefulWidget {
  const DoctorScreen({super.key, required this.doctor});

  final DoctorModel doctor;

  @override
  State<DoctorScreen> createState() => _DoctorScreenState();
}

class _DoctorScreenState extends State<DoctorScreen> {
  final AppointmentsBloc bloc = AppointmentsBloc();

  @override
  void initState() {
    bloc.add(const AppointmentsEvent.getDoctorAppointments());
    super.initState();
  }

  String selectedAppointment = '';

  String selectedTime = '';

  String selectedDate = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back,
            color: Colors.black,
          ),
          onPressed: () {
            context.router.maybePop();
          },
        ),
        title: Text(
          'Doctor',
          style: context.textTheme.headlineMedium,
        ),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.symmetric(
          horizontal: 4.w,
          vertical: 2.h,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                Container(
                  height: 100,
                  width: 100,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(width: 1, color: AppColors.black),
                  ),
                  clipBehavior: Clip.hardEdge,
                  child: const Icon(
                    FontAwesomeIcons.user,
                    color: AppColors.black,
                    size: 26,
                  ),
                ),
                Gap(3.w),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const ProffesionalDoctorBadge(),
                    Gap(1.h),
                    Text(
                      widget.doctor.name,
                      style: context.textTheme.titleLarge,
                    ),
                    Text(
                      widget.doctor.speciality,
                      style: context.textTheme.bodySmall,
                    ),
                    Gap(1.h),
                    RatingWidget(doctor: widget.doctor)
                  ],
                ),
                IconButton(
                  onPressed: () {
                    favoriteDoctorsList.add(widget.doctor);
                    setState(() {});
                  },
                  icon: favoriteDoctorsList.contains(widget.doctor)
                      ? const Icon(Icons.favorite)
                      : const Icon(Icons.favorite_border),
                )
              ],
            ),
            Gap(4.h),
            SizedBox(
              height: 8.h,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Column(
                    children: [
                      Text(
                        'Patients',
                        style: context.textTheme.bodyMedium,
                      ),
                      Text(
                        '${widget.doctor.patientCount}+',
                        style: context.textTheme.titleLarge,
                      ),
                    ],
                  ),
                  const VerticalDivider(),
                  Column(
                    children: [
                      Text(
                        'Experiences',
                        style: context.textTheme.bodyMedium,
                      ),
                      Text(
                        '${widget.doctor.experience}+',
                        style: context.textTheme.titleLarge,
                      ),
                    ],
                  ),
                  const VerticalDivider(),
                  Column(
                    children: [
                      Text(
                        'Ratings',
                        style: context.textTheme.bodyMedium,
                      ),
                      Text(
                        '${widget.doctor.ratingCount}',
                        style: context.textTheme.titleLarge,
                      ),
                    ],
                  ),
                ],
              ),
            ),
            Divider(height: 5.h),
            Text(
              'Select date:',
              style: context.textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.w600,
              ),
            ),
            Gap(2.h),
            SizedBox(
              height: 12.h,
              child: ListView(
                scrollDirection: Axis.horizontal,
                children: [
                  AppointmentOptionTile(
                    title: 'Mon, 20 April',
                    isSelected: selectedDate == 'Mon, 20 April',
                    onTap: () {
                      setState(() {
                        selectedDate = 'Mon, 20 April';
                      });
                    },
                  ),
                  AppointmentOptionTile(
                    title: 'Tue, 21 April',
                    isSelected: selectedDate == 'Tue, 21 April',
                    onTap: () {
                      setState(() {
                        selectedDate = 'Tue, 21 April';
                      });
                    },
                  ),
                  AppointmentOptionTile(
                    title: 'Wed, 22 April',
                    isSelected: selectedDate == 'Wed, 22 April',
                    onTap: () {
                      setState(() {
                        selectedDate = 'Wed, 22 April';
                      });
                    },
                  ),
                  AppointmentOptionTile(
                    title: 'Thu, 23 April',
                    isSelected: selectedDate == 'Thu, 23 April',
                    onTap: () {
                      setState(() {
                        selectedDate = 'Thu, 23 April';
                      });
                    },
                  ),
                  AppointmentOptionTile(
                    title: 'Fri, 24 April',
                    isSelected: selectedDate == 'Fri, 24 April',
                    onTap: () {
                      setState(() {
                        selectedDate = 'Fri, 24 April';
                      });
                    },
                  ),
                  AppointmentOptionTile(
                    title: 'Sat, 25 April',
                    isSelected: selectedDate == 'Sat, 25 April',
                    onTap: () {
                      setState(() {
                        selectedDate = 'Sat, 25 April';
                      });
                    },
                  ),
                  AppointmentOptionTile(
                    title: 'Sun, 26 April',
                    isSelected: selectedDate == 'Sun, 26 April',
                    onTap: () {
                      setState(() {
                        selectedDate = 'Sun, 26 April';
                      });
                    },
                  ),
                ],
              ),
            ),
            Text(
              'Select time:',
              style: context.textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.w600,
              ),
            ),
            Gap(2.h),
            SizedBox(
              height: 8.h,
              child: ListView(
                scrollDirection: Axis.horizontal,
                children: [
                  AppointmentOptionTile(
                    title: '09:00',
                    isSelected: selectedTime == '09:00',
                    onTap: () {
                      setState(() {
                        selectedTime = '09:00';
                      });
                    },
                  ),
                  AppointmentOptionTile(
                    title: '10:00',
                    isSelected: selectedTime == '10:00',
                    onTap: () {
                      setState(() {
                        selectedTime = '10:00';
                      });
                    },
                  ),
                  AppointmentOptionTile(
                    title: '11:00',
                    isSelected: selectedTime == '11:00',
                    onTap: () {
                      setState(() {
                        selectedTime = '11:00';
                      });
                    },
                  ),
                  AppointmentOptionTile(
                    title: '12:00',
                    isSelected: selectedTime == '12:00',
                    onTap: () {
                      setState(() {
                        selectedTime = '12:00';
                      });
                    },
                  ),
                  AppointmentOptionTile(
                    title: '13:00',
                    isSelected: selectedTime == '13:00',
                    onTap: () {
                      setState(() {
                        selectedTime = '13:00';
                      });
                    },
                  ),
                  AppointmentOptionTile(
                    title: '14:00',
                    isSelected: selectedTime == '14:00',
                    onTap: () {
                      setState(() {
                        selectedTime = '14:00';
                      });
                    },
                  ),
                  AppointmentOptionTile(
                    title: '15:00',
                    isSelected: selectedTime == '15:00',
                    onTap: () {
                      setState(() {
                        selectedTime = '15:00';
                      });
                    },
                  ),
                ],
              ),
            ),
            Gap(2.h),
            ElevatedButton(
              onPressed: () {
                appointmentsList.add(
                  AppointmentModel(
                    doctor: widget.doctor,
                    date: selectedDate,
                    time: selectedTime,
                    appointmentType: selectedAppointment,
                  ),
                );
                setState(() {});
                context.router.replace(
                  const AppointmentsRoute(),
                );
              },
              style: ButtonStyle(
                backgroundColor: MaterialStateColor.resolveWith(
                    (states) => AppColors.primary),
              ),
              child: Text(
                'Make appointment',
                style: context.textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
