import 'package:auto_route/auto_route.dart';
import 'package:flutter/material.dart';
import 'package:med_app/src/core/extensions/context_extension.dart';
import 'package:med_app/src/mock_data.dart';
import 'package:med_app/src/presentation/search/widgets/pharmacy_card.dart';

@RoutePage()
class PharmaciesScreen extends StatefulWidget {
  const PharmaciesScreen({super.key});

  @override
  State<PharmaciesScreen> createState() => _PharmaciesScreenState();
}

class _PharmaciesScreenState extends State<PharmaciesScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back,
            color: Colors.black,
          ),
          onPressed: () {
            context.router.maybePop();
          },
        ),
        title: Text('Pharmacies', style: context.textTheme.headlineMedium),
      ),
      body: SafeArea(
        top: true,
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: [
              Expanded(
                child: ListView(
                  children: List.from(
                    pharmaciesList.map(
                      (pharmacy) {
                        return PharmacyCard(
                          pharmacyName: pharmacy,
                        );
                      },
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
