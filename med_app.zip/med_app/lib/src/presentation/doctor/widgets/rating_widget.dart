import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:med_app/src/presentation/search/models/doctor_model.dart';

class RatingWidget extends StatelessWidget {
  const RatingWidget({super.key, required this.doctor});

  final DoctorModel doctor;

  @override
  Widget build(BuildContext context) {
    List<Widget> stars = [];

    for (int i = 0; i < 5; i++) {
      if (doctor.rating! >= i + 1) {
        stars.add(Icon(
          FontAwesomeIcons.solidStar,
          color: Colors.yellow.shade600,
          size: 16,
        ));
      } else if (doctor.rating! > i) {
        stars.add(Icon(
          FontAwesomeIcons.starHalfStroke,
          color: Colors.yellow.shade600,
          size: 16,
        ));
      } else {
        stars.add(Icon(
          FontAwesomeIcons.star,
          color: Colors.yellow.shade600,
          size: 16,
        ));
      }
    }

    return Row(
      children: stars,
    );
  }
}
