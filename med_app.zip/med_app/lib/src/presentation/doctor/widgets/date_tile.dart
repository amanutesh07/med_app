import 'package:flutter/material.dart';
import 'package:med_app/src/core/extensions/context_extension.dart';
import 'package:med_app/src/shared/colors/app_colors.dart';
import 'package:responsive_sizer/responsive_sizer.dart';

class DateTile extends StatelessWidget {
  const DateTile({
    super.key,
    required this.dayName,
    required this.day,
  });

  final String dayName;
  final int day;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8),
      child: Container(
        width: 20.w,
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: AppColors.black.withOpacity(0.12),
          borderRadius: BorderRadius.circular(30),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Text(dayName, style: context.textTheme.titleLarge),
            Text(day.toString(), style: context.textTheme.titleLarge),
          ],
        ),
      ),
    );
  }
}
