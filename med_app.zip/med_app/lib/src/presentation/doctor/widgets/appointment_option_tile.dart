import 'package:flutter/material.dart';
import 'package:med_app/src/core/extensions/context_extension.dart';

import '../../../shared/colors/app_colors.dart';

class AppointmentOptionTile extends StatefulWidget {
  const AppointmentOptionTile({
    super.key,
    required this.title,
    required this.isSelected,
    required this.onTap,
  });

  final String title;
  final bool isSelected;
  final VoidCallback onTap;

  @override
  State<AppointmentOptionTile> createState() => _AppointmentOptionTileState();
}

class _AppointmentOptionTileState extends State<AppointmentOptionTile> {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: InkWell(
        onTap: () {
          widget.onTap();
        },
        child: Container(
          decoration: BoxDecoration(
            color: !widget.isSelected
                ? Colors.grey.shade200
                : AppColors.black.withOpacity(0.15),
            borderRadius: BorderRadius.circular(18),
          ),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 2.5),
            child: Center(
              child: Text(
                widget.title,
                style: context.textTheme.bodyMedium,
              ),
            ),
          ),
        ),
      ),
    );
  }
}
