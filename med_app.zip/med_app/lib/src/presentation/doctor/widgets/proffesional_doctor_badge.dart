import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:med_app/src/core/extensions/context_extension.dart';
import 'package:responsive_sizer/responsive_sizer.dart';

class ProffesionalDoctorBadge extends StatelessWidget {
  const ProffesionalDoctorBadge({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(5),
      decoration: BoxDecoration(
        color: Colors.blue.shade100,
        borderRadius: BorderRadius.circular(30),
      ),
      child: Row(
        children: [
          const Icon(
            Icons.verified,
            size: 16,
          ),
          Gap(2.w),
          Text(
            'Professional doctor',
            style: context.textTheme.bodyMedium,
          ),
        ],
      ),
    );
  }
}
