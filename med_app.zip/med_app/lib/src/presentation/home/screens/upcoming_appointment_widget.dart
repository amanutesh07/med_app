import 'dart:math';

import 'package:auto_route/auto_route.dart';
import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:med_app/gen/assets.gen.dart';
import 'package:med_app/src/core/extensions/context_extension.dart';
import 'package:med_app/src/mock_data.dart';
import 'package:med_app/src/presentation/search/models/doctor_model.dart';
import 'package:med_app/src/router/app_router.gr.dart';
import 'package:med_app/src/shared/colors/app_colors.dart';
import 'package:med_app/src/shared/widgets/icon_frame.dart';
import 'package:responsive_sizer/responsive_sizer.dart';

class UpcomingAppointmentWidget extends StatelessWidget {
  const UpcomingAppointmentWidget({super.key, required this.doctor});

  final DoctorModel doctor;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: 3.w,
        vertical: 1.4.h,
      ),
      decoration: BoxDecoration(
        color: AppColors.grey,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Container(
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: AppColors.white,
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: AppColors.primary,
                        width: 2,
                      ),
                    ),
                    child: Assets.images.doctor.image(),
                  ),
                  const Gap(10),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        doctor.name,
                        style: context.textTheme.titleMedium,
                      ),
                      Text(
                        doctor.speciality,
                        style: context.textTheme.bodySmall,
                      ),
                    ],
                  ),
                ],
              ),
              InkWell(
                onTap: () {
                  context.router.push(
                    ConsultationRoute(
                        appointment: appointmentsList
                            .where((element) => element.doctor == doctor)
                            .first,
                        consultation: consultationsList[
                            Random.secure().nextInt(consultationsList.length)]),
                  );
                },
                child: IconFrame(
                  icon: Assets.icons.consultation,
                  padding: 10,
                ),
              ),
            ],
          ),
          Gap(1.5.h),
          Container(
            padding: const EdgeInsets.symmetric(
              horizontal: 10,
              vertical: 6,
            ),
            decoration: BoxDecoration(
              color: AppColors.background,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    Assets.icons.calendar.svg(),
                    const Gap(8),
                    Text(
                      appointmentsList
                          .where((element) => element.doctor == doctor)
                          .first
                          .date,
                      style: context.textTheme.labelSmall,
                    ),
                  ],
                ),
                Row(
                  children: [
                    Text(
                      appointmentsList
                          .where((element) => element.doctor == doctor)
                          .first
                          .time,
                      style: context.textTheme.labelSmall,
                    ),
                    const Gap(8),
                    Assets.icons.time.svg(),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
