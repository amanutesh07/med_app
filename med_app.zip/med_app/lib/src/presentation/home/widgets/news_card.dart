import 'package:flutter/material.dart';
import 'package:med_app/gen/assets.gen.dart';
import 'package:med_app/src/core/extensions/context_extension.dart';
import 'package:med_app/src/shared/colors/app_colors.dart';
import 'package:responsive_sizer/responsive_sizer.dart';

class NewsCard extends StatelessWidget {
  const NewsCard({super.key});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {},
      child: Container(
        height: 10.h,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          color: AppColors.grey,
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 7.5),
              child: Container(
                width: 15.w,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: AppColors.white,
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: AppColors.primary,
                    width: 2,
                  ),
                ),
                child: Assets.images.doctor.image(
                  scale: 0.80,
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10),
              child: Column(
                mainAxisSize: MainAxisSize.max,
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Dr. Almera Bairova',
                    style: context.textTheme.headlineMedium?.copyWith(
                      color: AppColors.black,
                      fontWeight: FontWeight.w400,
                      fontSize: 16,
                    ),
                  ),
                  Text(
                    'Therapist consultation',
                    style: context.textTheme.headlineSmall?.copyWith(
                      color: AppColors.black.withOpacity(0.5),
                      fontSize: 12,
                    ),
                  ),
                  Text(
                    'Most Frequently Visited Doctor. Doctor Of The Month.',
                    style: context.textTheme.headlineSmall?.copyWith(
                      fontSize: 10,
                      color: AppColors.black,
                    ),
                    maxLines: 5,
                  ),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}
