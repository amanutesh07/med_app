import 'package:flutter/material.dart';
import 'package:med_app/src/core/extensions/context_extension.dart';
import 'package:med_app/src/shared/colors/app_colors.dart';
import 'package:responsive_sizer/responsive_sizer.dart';

class AdviceCard extends StatelessWidget {
  const AdviceCard({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 24.w,
      padding: const EdgeInsets.all(3),
      decoration: BoxDecoration(
        border: Border.all(width: 3, color: AppColors.primary),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Container(
        padding: const EdgeInsets.all(4),
        decoration: BoxDecoration(
          color: AppColors.primary.withOpacity(0.2),
          borderRadius: BorderRadius.circular(5),
        ),
        child: Text(
          'Почему важно не опаздывать',
          style: context.textTheme.bodySmall?.copyWith(
            color: AppColors.black,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
    );
  }
}
