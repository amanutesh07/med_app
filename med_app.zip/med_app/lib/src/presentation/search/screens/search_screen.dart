import 'package:auto_route/auto_route.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:gap/gap.dart';
import 'package:med_app/src/core/extensions/context_extension.dart';
import 'package:med_app/src/mock_data.dart';
import 'package:med_app/src/presentation/search/widgets/doctor_search_card.dart';
import 'package:med_app/src/presentation/search/widgets/search_option_button.dart';
import 'package:med_app/src/router/app_router.gr.dart';
import 'package:med_app/src/shared/app_bar/my_app_bar.dart';
import 'package:med_app/src/shared/inputs/text_input.dart';
import 'package:responsive_sizer/responsive_sizer.dart';

@RoutePage()
class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  String doctorName = '';

  List<String> searchResults = [];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: MyAppBar(
        automaticallyImplyLeading: false,
        centerTitle: false,
        title: Text(
          'Search',
          style: context.textTheme.headlineSmall?.copyWith(
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
      body: SafeArea(
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
          child: Column(
            children: [
              TextInput(
                hintText: 'Search for a doctor',
                onChanged: (value) {
                  setState(() {
                    doctorName = value;
                  });
                },
              ),
              Divider(height: 4.h),
              SearchOptionButton(
                icon: FontAwesomeIcons.userDoctor,
                title: 'Favorite Doctors',
                onTap: () {
                  setState(() {});
                  context.router.push(const FavoriteDoctorsRoute());
                },
              ),
              // Padding(
              //   padding: EdgeInsets.symmetric(horizontal: 2.w),
              //   child: Column(
              //     children: [
              //       SearchOptionButton(
              //         icon: FontAwesomeIcons.map,
              //         title: 'На карте',
              //         onTap: () {},
              //       ),
              //       Divider(height: 4.h),
              //       SearchOptionButton(
              //         icon: FontAwesomeIcons.grip,
              //         title: 'По категориям',
              //         onTap: () {},
              //       ),
              //       Divider(height: 4.h),

              //     ],
              //   ),
              // ),
              Divider(height: 4.h),
              // i need to add list of doctors here based on the search

              Expanded(
                child: ListView(
                  children: List.from(
                    doctorsList.map(
                      (doctor) {
                        return DoctorSearchCard(
                          doctor: doctor,
                        );
                      },
                    ).where((element) {
                      return element.doctor.name
                          .toLowerCase()
                          .contains(doctorName.toLowerCase());
                    }),
                  ),
                ),
              ),

              Gap(1.h),
              // doctorName == 'Dr. John Doe'
              //     ? const Row(
              //         children: [
              //           DoctorSearchCard(
              //             doctorName: 'Dr. John Doe',
              //             speciality: 'Cardiologist',
              //           ),
              //         ],
              //       )
              //     : const SizedBox(),

              // Row(
              //   children: [
              //     const DoctorSearchCard(
              //       doctorName: 'Dr. John Doe',
              //       speciality: 'Cardiologist',
              //     ),
              //     Gap(4.w),
              //     const DoctorSearchCard(
              //       doctorName: 'Dr. John Doe',
              //       speciality: 'Cardiologist',
              //     ),
              //   ],
              // ),
              // Gap(4.w),
              // Row(
              //   children: [
              //     const DoctorSearchCard(
              //       doctorName: 'Dr. John Doe',
              //       speciality: 'Cardiologist',
              //     ),
              //     Gap(4.w),
              //     const DoctorSearchCard(
              //       doctorName: 'Dr. John Doe',
              //       speciality: 'Cardiologist',
              //     ),
              //   ],
              // ),
            ],
          ),
        ),
      ),
    );
  }
}
