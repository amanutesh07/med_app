import 'package:auto_route/auto_route.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:gap/gap.dart';
import 'package:med_app/src/core/extensions/context_extension.dart';
import 'package:med_app/src/presentation/search/models/doctor_model.dart';
import 'package:med_app/src/router/app_router.gr.dart';
import 'package:med_app/src/shared/colors/app_colors.dart';
import 'package:responsive_sizer/responsive_sizer.dart';

class DoctorSearchCard extends StatelessWidget {
  const DoctorSearchCard({
    super.key,
    required this.doctor,
  });

  final DoctorModel doctor;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: InkWell(
        onTap: () {
          context.router.push(DoctorRoute(doctor: doctor));
        },
        child: Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: AppColors.black.withOpacity(0.1),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Icon(
                FontAwesomeIcons.userDoctor,
                size: 30,
              ),
              Gap(2.h),
              Text(
                doctor.name,
                style: context.textTheme.titleLarge,
              ),
              Text(
                doctor.speciality,
                style: context.textTheme.titleSmall,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
