class DoctorModel {
  final String name;
  final String speciality;
  final String? imageUrl;
  final double? rating;
  final int? ratingCount;
  final String? experience;
  final String? patientCount;

  DoctorModel({
    required this.name,
    required this.speciality,
    this.imageUrl,
    this.rating,
    this.ratingCount,
    this.experience,
    this.patientCount,
  });
}
