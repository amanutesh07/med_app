class ConsultationModel {
  final String consultation;
  final String recommendation;

  ConsultationModel({
    required this.consultation,
    required this.recommendation,
  });
}
