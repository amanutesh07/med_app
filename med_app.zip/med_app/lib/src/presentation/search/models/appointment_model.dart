import 'package:med_app/src/presentation/search/models/doctor_model.dart';

class AppointmentModel {
  final DoctorModel doctor;
  final String date;
  final String time;
  final String type;

  AppointmentModel({
    required this.doctor,
    required this.date,
    required this.time,
    required this.type,
  });
}
