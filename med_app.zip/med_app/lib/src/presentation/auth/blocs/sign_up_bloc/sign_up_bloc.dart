import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:injectable/injectable.dart';
import 'package:med_app/src/core/enums/basics.dart';
import 'package:med_app/src/presentation/auth/core/enums.dart';
import 'package:med_app/src/presentation/base/app.dart';
import 'package:med_app/src/router/app_router.gr.dart';

part 'sign_up_event.dart';
part 'sign_up_state.dart';
part 'sign_up_bloc.freezed.dart';

@injectable
class SignUpBloc extends Bloc<SignUpEvent, SignUpState> {
  SignUpBloc() : super(SignUpState()) {
    on<NextField>(onNextField);
  }

  void onNextField(
    NextField event,
    Emitter<SignUpState> emit,
  ) async {
    final currentFieldsView = state.currentFieldsView;

    switch (currentFieldsView) {
      case SUFV.emailPassword:
        {
          break;
        }
      case SUFV.finish:
        {
          router
            ..popUntilRoot()
            ..replace(const NavRouter());
          break;
        }
      default:
        break;
    }

    emit(state.copyWith(
      currentFieldsView: switch (state.currentFieldsView) {
        SUFV.emailPassword => SUFV.finish,
        SUFV.finish => SUFV.finish,
      },
    ));
    emit(state.copyWith(
      currentStepNumber: SUFV.values.indexOf(state.currentFieldsView) + 1,
    ));
  }
}
