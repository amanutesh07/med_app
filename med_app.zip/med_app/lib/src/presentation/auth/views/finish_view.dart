import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:med_app/src/core/extensions/context_extension.dart';
import 'package:responsive_sizer/responsive_sizer.dart';

class FinishView extends StatelessWidget {
  const FinishView({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        const Icon(Icons.check_circle, size: 200, color: Colors.green),
        Gap(4.h),
        Text(
          'Registration Completed',
          style: context.textTheme.headlineMedium?.copyWith(
            fontWeight: FontWeight.w600,
          ),
          textAlign: TextAlign.center,
        ),
        Gap(12.h),
      ],
    );
  }
}
