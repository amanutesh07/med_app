import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:med_app/src/shared/inputs/text_input.dart';
import 'package:responsive_sizer/responsive_sizer.dart';

import '../../../mock_data.dart';

class EmailPasswordFieldView extends StatelessWidget {
  const EmailPasswordFieldView({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Gap(2.h),
        TextInput(
          label: 'Username',
          hintText: 'Enter username',
          keyboardType: TextInputType.emailAddress,
          onChanged: (value) {
            username = value;
          },
        ),
        Gap(2.h),
        TextInput(
          label: 'E-mail',
          hintText: 'Enter e-mail',
          keyboardType: TextInputType.emailAddress,
          onChanged: (value) {
            email = value;
          },
        ),
        Gap(2.h),
        TextInput(
          label: 'Password',
          hintText: 'Enter password',
          obscureText: true,
          keyboardType: TextInputType.visiblePassword,
          onChanged: (value) {
            password = value;
          },
        ),
      ],
    );
  }
}
