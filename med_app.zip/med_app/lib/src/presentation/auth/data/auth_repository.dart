import 'package:dartz/dartz.dart';
import 'package:injectable/injectable.dart';
import 'package:med_app/src/core/services/base_client.dart';
import 'package:med_app/src/presentation/auth/domain/i_auth_repository.dart';
import 'package:med_app/src/presentation/auth/domain/models/register_body.dart';
import 'package:med_app/src/presentation/auth/domain/models/sign_in_body.dart';
import 'package:med_app/src/presentation/auth/domain/models/tokens_entity.dart';

import '../../../core/exceptions/failure.dart';
import '../domain/models/change_password_body.dart';
import '../domain/models/tokens_model.dart';

@LazySingleton(as: IAuthRepository)
class AuthRepository extends BaseClient implements IAuthRepository {
  // @override
  // Future<Either<Failure, SocialSignInResponse>> signIn({
  //   required SignInBody body,
  // }) async {
  //   final request = await call(
  //     RestMethod.post,
  //     '/api/v1/authenticate',
  //     body: body.toMap(),
  //   );
  //   return request.fold(
  //     (l) => Left(l),
  //     (r) => Right(SocialSignInResponse.fromMap(r)),
  //   );
  // }

  @override
  Future<Either<Failure, Unit>> register({
    required RegisterBody body,
  }) async {
    final request = await call(
      RestMethod.post,
      '/auth/users/',
      body: body.toRegisterMap(),
    );
    return request.fold(
      (l) => Left(l),
      (r) => const Right(unit),
    );
  }

  @override
  Future<Either<Failure, TokensEntity>> createJwtToken({
    required SignInBody body,
  }) async {
    final request = await call(
      RestMethod.post,
      '/auth/jwt/create',
      body: body.toRegisterMap(),
    );

    return request.fold(
      (l) => Left(l),
      (r) {
        return Right(TokensModel.fromMap(r));
      },
    );
  }

  @override
  Future<Either<Failure, Unit>> setPassword(
    ChangePasswordBody body,
  ) async {
    final request = await call(
      RestMethod.post,
      '/auth/users/set_password/',
      body: body.toMap(),
    );
    return request.fold(
      (l) => Left(l),
      (r) => const Right(unit),
    );
  }

  // @override
  // Future<Either<Failure, Unit>> activate({
  //   required RegisterBody body,
  // }) async {
  //   final request = await call(
  //     RestMethod.post,
  //     '/api/v1/activate',
  //     parametres: body.toConfirmCodeMap(),
  //   );
  //   return request.fold(
  //     (l) => Left(l),
  //     (r) => const Right(unit),
  //   );
  // }

  // @override
  // Future<Either<Failure, Unit>> getAuthenticated() async {
  //   final request = await call(
  //     RestMethod.get,
  //     '/api/v1/authenticate',
  //   );
  //   return request.fold(
  //     (l) => Left(l),
  //     (r) => const Right(unit),
  //   );
  // }

  // @override
  // Future<Either<Failure, SocialSignInResponse>> signInWithApple(
  //   SignInWithSocialBody body,
  // ) async {
  //   final request = await call(
  //     RestMethod.post,
  //     '/api/v1/apple-auth',
  //     body: body.toMap(),
  //   );
  //   return request.fold(
  //     (l) => Left(l),
  //     (r) => Right(SocialSignInResponse.fromMap(r)),
  //   );
  // }

  // @override
  // Future<Either<Failure, SocialSignInResponse>> signInWithGoogle(
  //   SignInWithSocialBody body,
  // ) async {
  //   final request = await call(
  //     RestMethod.post,
  //     '/api/v1/google-auth',
  //     body: body.toMap(),
  //   );
  //   return request.fold(
  //     (l) => Left(l),
  //     (r) => Right(SocialSignInResponse.fromMap(r)),
  //   );
  // }

  // @override
  // Future<Either<Failure, Unit>> changeLanguage(
  //   LangType type,
  //   Lang lang,
  // ) async {
  //   final request = await call(
  //     RestMethod.post,
  //     '/api/v1/lang',
  //     body: {
  //       'type': type.name.toUpperCase(),
  //       'lang': lang.name.toUpperCase(),
  //     },
  //   );
  //   return request.fold(
  //     (l) => Left(l),
  //     (r) => const Right(unit),
  //   );
  // }

  // @override
  // Future<Either<Failure, Unit>> saveMessagingToken(String? token) async {
  //   final request = await call(
  //     RestMethod.post,
  //     '/api/v1/notification/save-token',
  //     body: {
  //       'token': token,
  //       'deviceType': Platform.isIOS ? 'ios' : 'android',
  //     },
  //   );
  //   return request.fold(
  //     (l) => Left(l),
  //     (r) => const Right(unit),
  //   );
  // }

  // @override
  // Future<Either<Failure, Unit>> deactivate(String password) async {
  //   final request = await call(
  //     RestMethod.post,
  //     '/api/v1/deactivate',
  //     body: {'password': password},
  //   );
  //   return request.fold(
  //     (l) => Left(l),
  //     (r) => const Right(unit),
  //   );
  // }

  // @override
  // Future<Either<Failure, Unit>> resetPasswordFinish(
  //   ResetPasswordBody body,
  // ) async {
  //   final request = await call(
  //     RestMethod.post,
  //     '/api/v1/account/reset-password/finish',
  //     body: body.toFinish(),
  //   );
  //   return request.fold(
  //     (l) => Left(l),
  //     (r) => const Right(unit),
  //   );
  // }

  // @override
  // Future<Either<Failure, Unit>> resetPasswordInit(
  //   ResetPasswordBody body,
  // ) async {
  //   final request = await call(
  //     RestMethod.post,
  //     '/api/v1/account/reset-password/init',
  //     body: body.toInit(),
  //   );
  //   return request.fold(
  //     (l) => Left(l),
  //     (r) => const Right(unit),
  //   );
  // }
}
