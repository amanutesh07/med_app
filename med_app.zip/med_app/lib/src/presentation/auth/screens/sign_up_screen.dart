import 'package:auto_route/auto_route.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:gap/gap.dart';
import 'package:med_app/src/core/dependencies/injection.dart';
import 'package:med_app/src/core/enums/basics.dart';
import 'package:med_app/src/core/extensions/context_extension.dart';
import 'package:med_app/src/core/services/auth_service.dart';
import 'package:med_app/src/presentation/auth/blocs/sign_up_bloc/sign_up_bloc.dart';
import 'package:med_app/src/presentation/auth/core/enums.dart';
import 'package:med_app/src/presentation/auth/views/finish_view.dart';
import 'package:med_app/src/shared/buttons/colored_button.dart';
import 'package:med_app/src/shared/inputs/text_input.dart';
import 'package:med_app/src/shared/tools/hide_behind_keyboard.dart';
import 'package:med_app/src/shared/widgets/logo_title.dart';
import 'package:responsive_sizer/responsive_sizer.dart';

import '../../../mock_data.dart';

class _Provider extends StatelessWidget {
  const _Provider({required this.child});

  final Widget child;

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) => getIt<SignUpBloc>(),
      child: child,
    );
  }
}

@RoutePage()
class SignUpScreen extends StatelessWidget {
  const SignUpScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final TextEditingController usernameController = TextEditingController();
    final TextEditingController emailController = TextEditingController();
    final TextEditingController passwordController = TextEditingController();

    void register(BuildContext context) async {
      final username = usernameController.text.trim();
      final email = emailController.text.trim();
      final password = passwordController.text.trim();

      final authService = AuthService();
      final success = await authService.register(username, email, password);

      if (success) {
        // Registration successful, navigate to login screen
        // Navigator.pushReplacementNamed(context, '/');
        print('Registration successful');
      } else {
        // Show error message
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
              content: Text('Registration failed. Please try again.')),
        );
      }
    }

    return _Provider(
      child: BlocBuilder<SignUpBloc, SignUpState>(
        builder: (context, state) {
          final stepText = switch (state.currentFieldsView) {
            SUFV.emailPassword => 'Register with your email and password',
            SUFV.finish => '',
          };
          final stepView = switch (state.currentFieldsView) {
            SUFV.emailPassword => Column(
                children: [
                  Gap(2.h),
                  TextInput(
                    label: 'Username',
                    hintText: 'Enter username',
                    keyboardType: TextInputType.emailAddress,
                    controller: usernameController,
                    onChanged: (value) {
                      username = value;
                    },
                  ),
                  Gap(2.h),
                  TextInput(
                    label: 'E-mail',
                    hintText: 'Enter e-mail',
                    controller: emailController,
                    keyboardType: TextInputType.emailAddress,
                    onChanged: (value) {
                      email = value;
                    },
                  ),
                  Gap(2.h),
                  TextInput(
                    label: 'Password',
                    hintText: 'Enter password',
                    obscureText: true,
                    controller: passwordController,
                    keyboardType: TextInputType.visiblePassword,
                    onChanged: (value) {
                      password = value;
                    },
                  ),
                ],
              ),
            SUFV.finish => const FinishView(),
          };
          return Scaffold(
            body: SafeArea(
              child: Padding(
                padding: EdgeInsets.symmetric(
                  horizontal: 5.w,
                ).copyWith(bottom: 2.h),
                child: Column(
                  children: [
                    Padding(
                      padding: EdgeInsets.symmetric(vertical: 5.h),
                      child: const LogoTitle(),
                    ),
                    Text(
                      stepText,
                      style: context.textTheme.headlineSmall?.copyWith(
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    Expanded(
                      child: Padding(
                        padding: EdgeInsets.symmetric(vertical: 2.h),
                        child: stepView,
                      ),
                    ),
                    HideBehindKeyoard(
                      slideOffset: const Offset(0, 3),
                      child: ColoredButton(
                        onTap: state.status != LoadStatus.loading
                            ? () {
                                register(context);
                                context.read<SignUpBloc>().add(
                                      const NextField(),
                                    );
                              }
                            : null,
                        title: 'Register',
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
