import 'package:auto_route/auto_route.dart';
import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:med_app/gen/assets.gen.dart';
import 'package:med_app/src/core/extensions/context_extension.dart';
import 'package:med_app/src/router/app_router.gr.dart';
import 'package:med_app/src/shared/buttons/colored_button.dart';
import 'package:med_app/src/shared/colors/app_colors.dart';
import 'package:med_app/src/shared/widgets/logo_title.dart';
import 'package:responsive_sizer/responsive_sizer.dart';

@RoutePage()
class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Expanded(
            child: Container(
              color: AppColors.secondary,
              child: Assets.images.doctors.image(
                fit: BoxFit.cover,
              ),
            ),
          ),
          Expanded(
            child: SafeArea(
              top: false,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Expanded(child: LogoTitle()),
                  Expanded(
                    flex: 2,
                    child: Padding(
                      padding: EdgeInsets.symmetric(horizontal: 10.w),
                      child: Column(
                        children: [
                          Text(
                            'Your Health, Our Priority',
                            style: context.textTheme.titleLarge?.copyWith(
                              fontWeight: FontWeight.w600,
                            ),
                            textAlign: TextAlign.center,
                          ),
                          const Gap(10),
                          Text(
                            'Medical Support Wherever You Are, Whenever You Need',
                            style: context.textTheme.titleSmall,
                            textAlign: TextAlign.center,
                          ),
                        ],
                      ),
                    ),
                  ),
                  Expanded(
                    flex: 2,
                    child: Padding(
                      padding: EdgeInsets.symmetric(horizontal: 20.w),
                      child: Column(
                        children: [
                          ColoredButton(
                            onTap: () => context.router.push(
                              const SignUpRoute(),
                            ),
                            title: 'Register',
                          ),
                          Gap(2.h),
                          ColoredButton(
                            onTap: () => context.router.replace(
                              const SignInRoute(),
                            ),
                            title: 'Login',
                            color: AppColors.white,
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
