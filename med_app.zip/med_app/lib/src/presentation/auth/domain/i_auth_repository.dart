import 'package:dartz/dartz.dart';
import 'package:med_app/src/core/exceptions/failure.dart';
import 'package:med_app/src/presentation/auth/domain/models/register_body.dart';
import 'package:med_app/src/presentation/auth/domain/models/sign_in_body.dart';
import 'package:med_app/src/presentation/auth/domain/models/tokens_entity.dart';

import 'models/change_password_body.dart';

abstract class IAuthRepository {
  // Future<Either<Failure, SocialSignInResponse>> signIn({
  //   required SignInBody body,
  // });

  Future<Either<Failure, Unit>> register({required RegisterBody body});

  Future<Either<Failure, TokensEntity>> createJwtToken(
      {required SignInBody body});

  // Future<Either<Failure, AccountEntity>> getAccount();

  Future<Either<Failure, Unit>> setPassword(ChangePasswordBody body);

  // Future<Either<Failure, Unit>> activate({
  //   required RegisterBody body,
  // });

  // Future<Either<Failure, Unit>> getAuthenticated();

  // Future<Either<Failure, SocialSignInResponse>> signInWithGoogle(
  //   SignInWithSocialBody body,
  // );

  // Future<Either<Failure, SocialSignInResponse>> signInWithApple(
  //   SignInWithSocialBody body,
  // );

  // Future<Either<Failure, Unit>> saveMessagingToken(String? token);

  // Future<Either<Failure, Unit>> deactivate(String password);

  // Future<Either<Failure, Unit>> resetPasswordInit(ResetPasswordBody body);

  // Future<Either<Failure, Unit>> resetPasswordFinish(ResetPasswordBody body);
}
