import 'package:equatable/equatable.dart';

class RegisterBody extends Equatable {
  final String username;
  final String email;
  final String password;

  const RegisterBody({
    required this.username,
    required this.email,
    required this.password,
  });

  static RegisterBody empty() => const RegisterBody(
        username: '',
        email: '',
        password: '',
      );

  Map<String, dynamic> toRegisterMap() => {
        'email': email,
        'password': password,
        'username': username,
      };

  RegisterBody copyWith({
    String? username,
    String? email,
    String? password,
  }) {
    return RegisterBody(
      username: username ?? this.username,
      email: email ?? this.email,
      password: password ?? this.password,
    );
  }

  @override
  List<Object?> get props => [
        username,
        email,
        password,
      ];
}
