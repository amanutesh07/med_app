import 'package:equatable/equatable.dart';

class SignInBody extends Equatable {
  final String username;
  final String password;

  const SignInBody({
    required this.username,
    required this.password,
  });

  static SignInBody empty(String? lang) => const SignInBody(
        username: '',
        password: '',
      );

  Map<String, dynamic> toRegisterMap() => {
        'password': password,
        'username': username,
      };

  SignInBody copyWith({
    String? username,
    String? password,
  }) {
    return SignInBody(
      username: username ?? this.username,
      password: password ?? this.password,
    );
  }

  @override
  List<Object?> get props => [
        username,
        password,
      ];
}
