import 'package:equatable/equatable.dart';

class ChangePasswordBody extends Equatable {
  final String currentPassword;
  final String newPassword;

  const ChangePasswordBody({
    required this.currentPassword,
    required this.newPassword,
  });

  factory ChangePasswordBody.empty() => const ChangePasswordBody(
        currentPassword: '',
        newPassword: '',
      );

  Map<String, dynamic> toMap() => {
        'current_password': currentPassword,
        'new_password': newPassword,
      };

  ChangePasswordBody copyWith({
    String? currentPassword,
    String? newPassword,
    String? confirmPassword,
  }) {
    return ChangePasswordBody(
      currentPassword: currentPassword ?? this.currentPassword,
      newPassword: newPassword ?? this.newPassword,
    );
  }

  @override
  List<Object?> get props => [
        currentPassword,
        newPassword,
      ];
}
