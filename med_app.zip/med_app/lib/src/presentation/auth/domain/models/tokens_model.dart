import 'package:med_app/src/presentation/auth/domain/models/tokens_entity.dart';

class TokensModel extends TokensEntity {
  const TokensModel({
    required super.refresh,
    required super.access,
  });

  factory TokensModel.fromMap(Map<String, dynamic> map) => TokensModel(
        refresh: map['refresh'] as String,
        access: map['access'] as String,
      );
}
