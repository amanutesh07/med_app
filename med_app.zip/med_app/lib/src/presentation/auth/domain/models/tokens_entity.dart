import 'package:equatable/equatable.dart';

class TokensEntity extends Equatable {
  final String refresh;
  final String access;

  const TokensEntity({
    required this.refresh,
    required this.access,
  });

  @override
  List<Object?> get props => [
        refresh,
        access,
      ];

  TokensEntity copyWith({
    String? refresh,
    String? access,
  }) {
    return TokensEntity(
      refresh: refresh ?? this.refresh,
      access: access ?? this.access,
    );
  }
}
