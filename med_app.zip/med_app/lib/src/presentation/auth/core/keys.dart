import 'package:flutter/material.dart';

// FORM KEYS
final emailPasswordFormKey = GlobalKey<FormState>();
final personalDataFormKey = GlobalKey<FormState>();

// CROPPER
final imageCropper = GlobalKey();
