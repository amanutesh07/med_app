enum SignInField { email, password }

enum SignUpField {
  email,
  code,
  password,
  passwordConfirm,
}

typedef SUFV = SignUpFieldsView;

enum SignUpFieldsView {
  emailPassword, // First enter email, then code field appears ...
  finish,
}

enum ThridPartyAuthType { signIn, signUp }
