import 'package:chucker_flutter/chucker_flutter.dart';
import 'package:flutter/material.dart';
import 'package:med_app/l10n/app_localizations.dart';
import 'package:med_app/src/core/services/auth_service.dart';
import 'package:med_app/src/presentation/base/app_theme_data.dart';
import 'package:med_app/src/presentation/base/globals.dart';
import 'package:med_app/src/router/app_router.dart';
import 'package:responsive_sizer/responsive_sizer.dart';

final router = AppRouter();

class App extends StatelessWidget {
  const App({super.key});

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<bool>(
      future: AuthService().isLoggedIn(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const CircularProgressIndicator(); // Show a loading indicator while checking login status
        } else {
          if (snapshot.data == true) {
            // User is logged in, navigate to the authenticated screen
            return _buildAppWithRouter(context);
          } else {
            // User is not logged in, navigate to the login screen
            return _buildAppWithRouter(context, initialRoute: '/login');
          }
        }
      },
    );
  }

  Widget _buildAppWithRouter(BuildContext context, {String? initialRoute}) {
    return ResponsiveSizer(
      builder: (_, __, ___) => MaterialApp.router(
        debugShowCheckedModeBanner: false,
        routerConfig: router.config(
          navigatorObservers: () => [
            ChuckerFlutter.navigatorObserver,
          ],
        ),
        theme: AppThemeData.themeData,
        scaffoldMessengerKey: snackbarKey,
        locale: const Locale('en'),
        localizationsDelegates: AppLocalizations.localizationsDelegates,
        supportedLocales: AppLocalizations.supportedLocales,
      ),
    );
  }
}
