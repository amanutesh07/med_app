import 'package:auto_route/auto_route.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:gap/gap.dart';
import 'package:med_app/src/core/extensions/context_extension.dart';
import 'package:med_app/src/presentation/appointments/presentation/bloc/bloc/appointments_bloc.dart';
import 'package:med_app/src/presentation/doctor/widgets/rating_widget.dart';
import 'package:med_app/src/router/app_router.gr.dart';
import 'package:med_app/src/shared/colors/app_colors.dart';
import 'package:responsive_sizer/responsive_sizer.dart';

import '../../../../mock_data.dart';

class AppointmentWidget extends StatefulWidget {
  const AppointmentWidget({
    super.key,
    required this.appointment,
    this.callback,
  });

  final AppointmentModel appointment;
  final VoidCallback? callback;

  @override
  State<AppointmentWidget> createState() => _AppointmentWidgetState();
}

class _AppointmentWidgetState extends State<AppointmentWidget> {
  showConfirmationDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) {
        return Padding(
          padding: const EdgeInsets.symmetric(horizontal: 50, vertical: 300),
          child: ConfirmationWidget(
            appointment: widget.appointment,
            callback: widget.callback!,
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.black.withOpacity(0.1),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Container(
              height: 10.h,
              decoration: BoxDecoration(
                color: AppColors.background,
                borderRadius: BorderRadius.circular(20),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Padding(
                    padding: const EdgeInsets.all(15.0),
                    child: Container(
                      height: 50,
                      width: 50,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(width: 1, color: AppColors.black),
                      ),
                      clipBehavior: Clip.hardEdge,
                      child: const Icon(
                        FontAwesomeIcons.user,
                        color: AppColors.black,
                        size: 26,
                      ),
                    ),
                  ),
                  Gap(1.w),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Gap(1.h),
                      Text(
                        widget.appointment.doctor.name,
                        style: context.textTheme.titleLarge,
                      ),
                      Text(
                        widget.appointment.doctor.speciality,
                        style: context.textTheme.bodySmall,
                      ),
                      Gap(1.h),
                      RatingWidget(doctor: widget.appointment.doctor)
                    ],
                  ),
                  const Spacer(),
                  IconButton(
                    onPressed: () {
                      showConfirmationDialog(context);
                    },
                    icon: const Icon(Icons.delete),
                  )
                ],
              ),
            ),
            Gap(1.h),
            SizedBox(
              height: 8.h,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Column(
                    children: [
                      Text(
                        'Patients',
                        style: context.textTheme.bodyMedium,
                      ),
                      Text(
                        '${widget.appointment.doctor.patientCount}+',
                        style: context.textTheme.titleLarge,
                      ),
                    ],
                  ),
                  const VerticalDivider(),
                  Column(
                    children: [
                      Text(
                        'Experiences',
                        style: context.textTheme.bodyMedium,
                      ),
                      Text(
                        '${widget.appointment.doctor.experience}+',
                        style: context.textTheme.titleLarge,
                      ),
                    ],
                  ),
                  const VerticalDivider(),
                  Column(
                    children: [
                      Text(
                        'Ratings',
                        style: context.textTheme.bodyMedium,
                      ),
                      Text(
                        '${widget.appointment.doctor.ratingCount}',
                        style: context.textTheme.titleLarge,
                      ),
                    ],
                  ),
                ],
              ),
            ),
            Gap(1.h),
            SizedBox(
              height: 6.h,
              child: InkWell(
                onTap: () {
                  context.router
                      .push(PaymentRoute(appointment: widget.appointment));
                },
                child: Container(
                  width: 30.w,
                  decoration: BoxDecoration(
                    color: AppColors.background,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text(
                      'Payment',
                      style: context.textTheme.titleLarge,
                      textAlign: TextAlign.center,
                    ),
                  ),
                ),
              ),
            ),
            Gap(1.h),
            Container(
              height: 12.h,
              decoration: BoxDecoration(
                color: AppColors.background,
                borderRadius: BorderRadius.circular(20),
              ),
              child: Padding(
                padding: const EdgeInsets.all(10.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Consultation',
                      style: context.textTheme.headlineSmall,
                      textAlign: TextAlign.start,
                    ),
                    Gap(0.5.h),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(
                          decoration: BoxDecoration(
                            color: AppColors.black.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                const Icon(
                                  Icons.calendar_month,
                                ),
                                Text(
                                  widget.appointment.date,
                                  style: context.textTheme.bodyMedium,
                                ),
                              ],
                            ),
                          ),
                        ),
                        Container(
                          decoration: BoxDecoration(
                            color: AppColors.black.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                const Icon(
                                  Icons.alarm,
                                ),
                                Text(
                                  widget.appointment.time,
                                  style: context.textTheme.bodyMedium,
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    )
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class ConfirmationWidget extends StatelessWidget {
  const ConfirmationWidget({
    super.key,
    required this.appointment,
    required this.callback,
  });

  final AppointmentModel appointment;
  final VoidCallback callback;

  @override
  Widget build(BuildContext context) {
    return Material(
      borderRadius: BorderRadius.circular(30),
      child: Container(
        height: 150,
        decoration: BoxDecoration(
          color: Colors.grey.shade200,
          borderRadius: BorderRadius.circular(30),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            Padding(
              padding: const EdgeInsets.all(10.0),
              child: Text(
                'Are you sure you want to delete this appointment?',
                style: context.textTheme.bodyMedium,
                textAlign: TextAlign.center,
              ),
            ),
            Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisSize: MainAxisSize.max,
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: InkWell(
                      onTap: () {
                        context.router.maybePop();
                      },
                      child: Container(
                        height: 60,
                        decoration: BoxDecoration(
                          color: AppColors.background,
                          borderRadius: BorderRadius.circular(30),
                        ),
                        child: const Center(
                          child: Padding(
                            padding: EdgeInsets.all(10.0),
                            child: Text('Cancel'),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: InkWell(
                      onTap: () {
                        appointmentsList.remove(appointment);
                        callback();
                        context.router.maybePop();
                      },
                      child: Container(
                        height: 60,
                        decoration: BoxDecoration(
                          color: AppColors.background,
                          borderRadius: BorderRadius.circular(30),
                        ),
                        child: const Center(
                          child: Padding(
                            padding: EdgeInsets.all(10.0),
                            child: Text('Confirm'),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
