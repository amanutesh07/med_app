import 'package:auto_route/auto_route.dart';
import 'package:flutter/material.dart';
import 'package:med_app/src/core/extensions/context_extension.dart';
import 'package:med_app/src/mock_data.dart';
import 'package:med_app/src/presentation/appointments/presentation/bloc/bloc/appointments_bloc.dart';
import 'package:med_app/src/presentation/search/models/consultation_mode.dart';
import 'package:med_app/src/router/app_router.gr.dart';

@RoutePage()
class ConsultationScreen extends StatefulWidget {
  const ConsultationScreen(
      {super.key, required this.consultation, required this.appointment});

  final ConsultationModel consultation;
  final AppointmentModel appointment;

  @override
  State<ConsultationScreen> createState() => _ConsultationScreenState();
}

class _ConsultationScreenState extends State<ConsultationScreen> {
  showSubmitPopup(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return Padding(
          padding: const EdgeInsets.symmetric(horizontal: 50, vertical: 250),
          child: Container(
            decoration: BoxDecoration(
              color: Colors.grey.shade200,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Padding(
              padding: const EdgeInsets.all(15.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Text(
                    'Thank you for feedback!',
                    style: context.textTheme.headlineSmall,
                  ),
                  const SizedBox(height: 20),
                  const Icon(
                    Icons.check_circle,
                    size: 100,
                    color: Colors.green,
                  )
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back,
            color: Colors.black,
          ),
          onPressed: () {
            context.router.maybePop();
          },
        ),
        title: Text(
          'Consultation',
          style: context.textTheme.headlineMedium,
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: SingleChildScrollView(
          child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: MediaQuery.of(context).size.width,
                  decoration: BoxDecoration(
                    color: Colors.grey.shade200,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(15.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Text(
                          'Consultation by ${widget.appointment.doctor.name} for $username',
                          style: context.textTheme.headlineSmall,
                        ),
                        const SizedBox(height: 20),
                        Text(
                          'Speciality: ${widget.appointment.doctor.speciality}',
                          style: context.textTheme.headlineSmall,
                        ),
                        const SizedBox(height: 20),
                        Text(
                          'Consultation fee: ${(int.tryParse(widget.appointment.doctor.patientCount!)! * 3)}',
                          style: context.textTheme.headlineSmall,
                        ),
                        const SizedBox(height: 20),
                        Text(
                          'Consultation duration: 2 hours',
                          style: context.textTheme.headlineSmall,
                        ),
                        const SizedBox(height: 20),
                        Text(
                          'Consultation date: ${DateTime.now().day}/${DateTime.now().month}/${DateTime.now().year}',
                          style: context.textTheme.headlineSmall,
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                Container(
                  decoration: BoxDecoration(
                    color: Colors.grey.shade200,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(15.0),
                    child: Text(
                      widget.consultation.consultation,
                      style: context.textTheme.headlineSmall,
                    ),
                  ),
                ),

                const SizedBox(
                  height: 20,
                ),

                Container(
                  decoration: BoxDecoration(
                    color: Colors.grey.shade200,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(15.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Text(
                          widget.consultation.recommendation,
                          style: context.textTheme.headlineSmall,
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(
                  height: 20,
                ),

                //Give feedback on doctor

                Container(
                  decoration: BoxDecoration(
                    color: Colors.grey.shade200,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(15.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Text(
                          'Give feedback on doctor',
                          style: context.textTheme.headlineSmall,
                        ),
                        const SizedBox(
                          height: 20,
                        ),
                        TextField(
                          maxLines: 5,
                          decoration: InputDecoration(
                            hintText: 'Enter feedback',
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                        ),
                        const SizedBox(
                          height: 20,
                        ),
                        InkWell(
                          onTap: () {
                            showSubmitPopup(context);
                            Future.delayed(const Duration(seconds: 5)).then(
                              (value) =>
                                  context.router.replace(const HomeRoute()),
                            );
                          },
                          child: Container(
                            decoration: BoxDecoration(
                              color: Colors.grey.shade300,
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: const Padding(
                              padding: EdgeInsets.all(8.0),
                              child: Text('Submit'),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                )
              ]),
        ),
      ),
    );
  }
}
