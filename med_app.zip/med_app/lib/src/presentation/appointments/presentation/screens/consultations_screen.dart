import 'package:auto_route/auto_route.dart';
import 'package:flutter/material.dart';
import 'package:med_app/src/core/extensions/context_extension.dart';
import 'package:med_app/src/mock_data.dart';
import 'package:med_app/src/presentation/home/screens/upcoming_appointment_widget.dart';

@RoutePage()
class ConsultationsScreen extends StatefulWidget {
  const ConsultationsScreen({super.key});

  @override
  State<ConsultationsScreen> createState() => _ConsultationsScreenState();
}

class _ConsultationsScreenState extends State<ConsultationsScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back,
            color: Colors.black,
          ),
          onPressed: () {
            context.router.maybePop();
          },
        ),
        title: Text(
          'Consultations',
          style: context.textTheme.headlineMedium,
        ),
      ),
      body: SizedBox(
        child: ListView.builder(
          itemCount: appointmentsList.length,
          itemBuilder: (context, index) {
            return Padding(
              padding: const EdgeInsets.all(15.0),
              child: UpcomingAppointmentWidget(
                doctor: appointmentsList[index].doctor,
              ),
            );
          },
        ),
      ),
    );
  }
}
