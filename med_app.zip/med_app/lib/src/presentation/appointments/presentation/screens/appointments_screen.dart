import 'package:auto_route/auto_route.dart';
import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:med_app/src/core/extensions/context_extension.dart';
import 'package:med_app/src/presentation/appointments/presentation/screens/appointment_widget.dart';
import 'package:responsive_sizer/responsive_sizer.dart';

import '../../../../mock_data.dart';

@RoutePage()
class AppointmentsScreen extends StatefulWidget {
  const AppointmentsScreen({super.key});

  @override
  State<AppointmentsScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<AppointmentsScreen> {
  @override
  void initState() {
    setState(() {});
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back,
            color: Colors.black,
          ),
          onPressed: () {
            context.router.maybePop();
          },
        ),
        title: Text(
          'Appointments',
          style: context.textTheme.headlineMedium,
        ),
      ),
      body: SafeArea(
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
          child: appointmentsList.isEmpty
              ? Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(
                        Icons.calendar_today_rounded,
                        size: 100,
                        color: Colors.grey,
                      ),
                      const Gap(20),
                      Text(
                        'There is no appointments',
                        style: context.textTheme.titleMedium,
                      ),
                    ],
                  ),
                )
              : ListView.builder(
                  itemCount: appointmentsList.length,
                  itemBuilder: (context, index) {
                    return SingleChildScrollView(
                      padding: EdgeInsets.symmetric(
                        horizontal: 4.w,
                        vertical: 2.h,
                      ),
                      child: AppointmentWidget(
                        appointment: appointmentsList[index],
                        callback: () {
                          setState(() {});
                        },
                      ),
                    );
                  },
                ),
        ),
      ),
    );
  }
}
