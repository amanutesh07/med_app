part of 'appointments_bloc.dart';

@freezed
class AppointmentsState with _$AppointmentsState {
  const factory AppointmentsState.initial() = _Initial;
  const factory AppointmentsState.loading() = _Loading;
  const factory AppointmentsState.loaded(AppointmentsViewModel viewModel) =
      _Loaded;
  const factory AppointmentsState.error(String message) = _Error;
}

@freezed
class AppointmentsViewModel with _$AppointmentsViewModel {
  factory AppointmentsViewModel({
    @Default(<AppointmentModel>[]) List<AppointmentModel> appointmentsList,
  }) = _AppointmentsViewModel;
}

class AppointmentModel {
  final DoctorModel doctor;
  final String date;
  final String time;
  final String appointmentType;

  AppointmentModel({
    required this.doctor,
    required this.date,
    required this.time,
    required this.appointmentType,
  });
}
