part of 'appointments_bloc.dart';

@freezed
class AppointmentsEvent with _$AppointmentsEvent {
  const factory AppointmentsEvent.started() = _Started;
  const factory AppointmentsEvent.getDoctorAppointments() =
      _GetDoctorAppointments;
}
