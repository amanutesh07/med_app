import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:injectable/injectable.dart';
import 'package:med_app/src/presentation/search/models/doctor_model.dart';

part 'appointments_bloc.freezed.dart';
part 'appointments_event.dart';
part 'appointments_state.dart';

@injectable
class AppointmentsBloc extends Bloc<AppointmentsEvent, AppointmentsState> {
  AppointmentsBloc() : super(const AppointmentsState.initial()) {
    on<_GetDoctorAppointments>(_getDoctorAppointments);
    on<_Started>(_started);

    add(const AppointmentsEvent.getDoctorAppointments());
  }

  AppointmentsViewModel _viewModel = AppointmentsViewModel();

  _started(_Started event, Emitter<AppointmentsState> emit) {
    emit(const AppointmentsState.initial());
  }

  _getDoctorAppointments(
      _GetDoctorAppointments event, Emitter<AppointmentsState> emit) {
    _viewModel = _viewModel.copyWith(
      appointmentsList: _viewModel.appointmentsList +
          [
            AppointmentModel(
              doctor: DoctorModel(
                name: 'Dr. John Doe',
                speciality: 'Cardiologist',
                imageUrl: 'https://example.com/doctor1.jpg',
                rating: 5,
                ratingCount: 500,
                experience: '10 years',
                patientCount: '500',
              ),
              date: '19.04.2024',
              time: '10:00',
              appointmentType: 'Hospital',
            ),
            AppointmentModel(
              doctor: DoctorModel(
                name: 'Dr. House',
                speciality: 'Dentist',
                imageUrl: 'https://example.com/doctor2.jpg',
                rating: 4.0,
                experience: '8 years',
                ratingCount: 300,
                patientCount: '300',
              ),
              appointmentType: 'Video Call',
              date: '14.04.2024',
              time: '13:00',
            )
          ],
    );

    emit(const AppointmentsState.loading());

    return emit(AppointmentsState.loaded(_viewModel));
  }
}
